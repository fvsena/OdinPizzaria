package model;

public enum TamanhoPizza {
	BROTO,
	MEDIA,
	GRANDE
}
