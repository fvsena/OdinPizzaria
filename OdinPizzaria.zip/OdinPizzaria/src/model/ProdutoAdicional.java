package model;

public class ProdutoAdicional extends Produto {
	public String marca;
}
