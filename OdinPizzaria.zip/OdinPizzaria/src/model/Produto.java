package model;

public class Produto {
	public String nome;
	public Double valor;
}
