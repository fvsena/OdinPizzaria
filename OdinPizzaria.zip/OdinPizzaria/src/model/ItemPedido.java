package model;

public class ItemPedido {
	public ProdutoAdicional adicional;
	public Pizza pizza;
	public int quantidade;
}
