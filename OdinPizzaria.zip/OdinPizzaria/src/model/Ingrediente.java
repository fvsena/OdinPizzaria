package model;

public class Ingrediente {
	public String nome;
}
