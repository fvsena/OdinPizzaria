package model;

public enum TipoAcesso {
	ATENDENTE,
	GERENTE
}
